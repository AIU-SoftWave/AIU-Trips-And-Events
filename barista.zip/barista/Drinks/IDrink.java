package barista.Drinks;

public interface IDrink {
    String getName();
    int getTemperature();
    void setName(String name);
    void setTemperature(int temperature);
}
